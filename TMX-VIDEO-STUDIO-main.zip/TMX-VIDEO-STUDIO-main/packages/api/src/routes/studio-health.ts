import type { FastifyInstance, FastifyPluginAsync } from 'fastify';

const plugin: FastifyPluginAsync = async (app: FastifyInstance) => {
  app.get('/healthz', async () => ({ status: 'ok', product: 'tmx-video-studio' }));
  app.get('/readyz', async (_request, reply) => {
    const checks = { redis: false, storage: false };
    try {
      checks.redis = (await app.redis.ping()) === 'PONG';
    } catch {}
    try {
      await app.storage.ping();
      checks.storage = true;
    } catch {}
    const ready = checks.redis && checks.storage;
    return reply.code(ready ? 200 : 503).send({ status: ready ? 'ok' : 'degraded', checks });
  });
};

export default plugin;
