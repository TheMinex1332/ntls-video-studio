import type { FastifyInstance, FastifyPluginAsync } from 'fastify';
import activityRoutes from './activity.js';
import authRoutes from './auth.js';
import mediaJobsRoutes from './media-jobs.js';
import nichesRoutes from './niches.js';
import studioHealthRoutes from './studio-health.js';
import usersRoutes from './users.js';

const plugin: FastifyPluginAsync = async (app: FastifyInstance) => {
  await app.register(studioHealthRoutes);
  await app.register(
    async (v1) => {
      await v1.register(authRoutes);
      await v1.register(async (protectedRoutes) => {
        protectedRoutes.addHook('preHandler', (request) => app.requireAuth(request));
        await protectedRoutes.register(activityRoutes);
        await protectedRoutes.register(nichesRoutes);
        await protectedRoutes.register(mediaJobsRoutes);
        await protectedRoutes.register(usersRoutes);
      });
    },
    { prefix: '/v1' },
  );
};

export default plugin;
