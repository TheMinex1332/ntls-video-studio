import Fastify from 'fastify';
import { env } from './env.js';
import { logger } from './lib/logger.js';
import authPlugin from './plugins/auth.js';
import corsPlugin from './plugins/cors.js';
import errorHandlerPlugin from './plugins/error-handler.js';
import multipartPlugin from './plugins/multipart.js';
import rateLimitPlugin from './plugins/rate-limit.js';
import storagePlugin from './plugins/studio-storage.js';
import queuePlugin from './plugins/studio-queue.js';
import swaggerPlugin from './plugins/swagger.js';
import routes from './routes/studio-routes.js';
import { createMediaWorker } from './workers/media.worker.js';

export async function buildStudioApp() {
  const app = Fastify({
    loggerInstance: logger,
    bodyLimit: 5 * 1024 * 1024,
    trustProxy: true,
  });
  await app.register(queuePlugin);
  await app.register(storagePlugin);
  await app.register(authPlugin);
  await app.register(corsPlugin);
  await app.register(rateLimitPlugin);
  await app.register(errorHandlerPlugin);
  await app.register(multipartPlugin);
  await app.register(swaggerPlugin);
  await app.register(routes);
  return app;
}

async function main() {
  const app = await buildStudioApp();
  const worker = env.MEDIA_WORKER_ENABLED
    ? createMediaWorker({
        redisUrl: env.REDIS_URL,
        jobStore: app.mediaJobStore,
        nicheStore: app.nicheStore,
        storage: app.storage,
      })
    : null;
  let stopping = false;
  const shutdown = async (signal: string) => {
    if (stopping) return;
    stopping = true;
    app.log.info({ signal }, 'studio shutdown initiated');
    await worker?.close();
    await app.close();
    process.exit(0);
  };
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));
  const port = env.PORT ?? env.API_PORT;
  await app.listen({ port, host: env.API_HOST });
  app.log.info({ mediaWorkerEnabled: env.MEDIA_WORKER_ENABLED }, `TMX Video Studio API listening on ${env.API_HOST}:${port}`);
}

if (process.argv[1]?.endsWith('studio-server.js') || process.argv[1]?.endsWith('studio-server.ts')) {
  void main();
}
