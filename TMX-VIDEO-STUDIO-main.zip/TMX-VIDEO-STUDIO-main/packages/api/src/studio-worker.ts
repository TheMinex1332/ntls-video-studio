import { env } from './env.js';
import { logger } from './lib/logger.js';
import { buildStudioApp } from './studio-server.js';
import { createMediaWorker } from './workers/media.worker.js';

async function main() {
  const app = await buildStudioApp();
  await app.ready();
  const worker = createMediaWorker({
    redisUrl: env.REDIS_URL,
    jobStore: app.mediaJobStore,
    nicheStore: app.nicheStore,
    storage: app.storage,
  });
  logger.info({ concurrency: env.MEDIA_WORKER_CONCURRENCY, ffmpegThreads: env.FFMPEG_THREADS_PER_JOB }, 'dedicated media worker started');
  let stopping = false;
  const shutdown = async (signal: string) => {
    if (stopping) return;
    stopping = true;
    logger.info({ signal }, 'media worker shutdown initiated');
    await worker.close();
    await app.close();
    process.exit(0);
  };
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));
}

void main().catch((error) => {
  logger.error({ error }, 'dedicated media worker failed to start');
  process.exit(1);
});
