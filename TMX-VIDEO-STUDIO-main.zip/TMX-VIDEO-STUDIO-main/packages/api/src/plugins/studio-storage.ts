import type { FastifyInstance, FastifyPluginAsync } from 'fastify';
import { InviteStore } from '../services/invite-store.js';
import { MediaJobStore } from '../services/media-job-store.js';
import { NicheStore } from '../services/niche-store.js';
import { StorageService } from '../services/storage.js';

const plugin: FastifyPluginAsync = async (app: FastifyInstance) => {
  const storage = new StorageService();
  app.decorate('storage', storage);
  app.decorate('nicheStore', new NicheStore(app.redis));
  app.decorate('mediaJobStore', new MediaJobStore(app.redis));
  app.decorate('inviteStore', new InviteStore(app.redis));
  app.addHook('onClose', async () => storage.close());
};

(plugin as unknown as Record<symbol, boolean>)[Symbol.for('skip-override')] = true;

export default plugin;
