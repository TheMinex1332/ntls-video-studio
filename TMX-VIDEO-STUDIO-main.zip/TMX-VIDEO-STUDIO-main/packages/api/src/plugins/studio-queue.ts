import type { Queue } from 'bullmq';
import type { FastifyInstance, FastifyPluginAsync } from 'fastify';
import type { Redis } from 'ioredis';
import { env } from '../env.js';
import { makeRedis } from '../lib/redis.js';
import type { MediaJobData } from '../queues/index.js';
import { createMediaQueue } from '../queues/media.queue.js';

declare module 'fastify' {
  interface FastifyInstance {
    redis: Redis;
    mediaQueue: Queue<MediaJobData>;
  }
}

const plugin: FastifyPluginAsync = async (app: FastifyInstance) => {
  const redis = makeRedis(env.REDIS_URL, {
    maxRetriesPerRequest: 3,
    connectTimeout: 5_000,
    enableReadyCheck: false,
  });
  const mediaQueue = createMediaQueue(env.REDIS_URL);
  redis.on('error', (error) => app.log.error({ error }, 'studio redis error'));
  app.decorate('redis', redis);
  app.decorate('mediaQueue', mediaQueue);
  app.addHook('onClose', async () => {
    await mediaQueue.close();
    await redis.quit();
  });
};

(plugin as unknown as Record<symbol, boolean>)[Symbol.for('skip-override')] = true;

export default plugin;
