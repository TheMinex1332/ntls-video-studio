import { NextResponse, type NextRequest } from 'next/server';

const PUBLIC_APP_PATHS = [
  '/',
  '/login',
  '/register',
  '/history',
  '/settings',
  '/admin',
  '/tools/video-shield',
];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  if (
    pathname.startsWith('/_next/') ||
    pathname.startsWith('/v1/') ||
    pathname.startsWith('/brand/') ||
    pathname === '/icon.svg' ||
    PUBLIC_APP_PATHS.some((path) => pathname === path || (path !== '/' && pathname.startsWith(`${path}/`)))
  ) {
    return NextResponse.next();
  }
  return NextResponse.redirect(new URL('/tools/video-shield', request.url));
}

export const config = {
  matcher: ['/((?!api|v1).*)'],
};
