'use client';

import { formatMoney, useDisplayCurrency } from '@/lib/currency-preference';
import { cn } from '@/lib/utils';

/**
 * The signal HUD at the top of the Tracker view.
 *
 * Two tiers, not six identical cards:
 *   - Tier 1: two hero readings (Compradores front, Faturamento) with big
 *     tabular figures and a satellite reading below each. If there are
 *     unmapped-front sales, that surfaces as an ember pulse next to buyers.
 *   - Tier 2: a HUD strip with the four supporting signals in compact
 *     lockup. Each has a mono value and a status pulse whose tone reflects
 *     the reading (data loss ember/scar, connect rate lush when >0).
 */

type Summary = {
  visitors: number;
  ad_clicks: number;
  connected_clicks: number;
  checkouts: number;
  checkout_events: number;
  paid_buyers: number;
  upsell_orders: number;
  upsell_2_orders?: number;
  upsell_3_orders?: number;
  unmapped_paid_orders: number;
  paid_revenue_minor: string;
  paid_revenue_brl_minor: string;
  paid_revenue_usd_minor: string;
  unconverted_paid_orders: number;
  webhooks_received: number;
  webhooks_quarantined: number;
  refunded_orders?: number;
  refunded_revenue_brl_minor?: string;
  refunded_revenue_usd_minor?: string;
  chargeback_orders?: number;
  refund_chargeback_fee_count?: number;
  refund_chargeback_fee_brl_minor?: string;
  refund_chargeback_fee_usd_minor?: string;
  chargeback_revenue_brl_minor?: string;
  chargeback_revenue_usd_minor?: string;
  fee_vendepay_brl_minor?: string;
  fee_vendepay_usd_minor?: string;
  fee_extra_brl_minor?: string;
  fee_extra_usd_minor?: string;
  reserve_brl_minor?: string;
  reserve_usd_minor?: string;
  net_revenue_brl_minor?: string;
  net_revenue_usd_minor?: string;
  net_available_brl_minor?: string;
  net_available_usd_minor?: string;
  fee_settings?: { reserve_days: number };
};

function percent(numerator: number, denominator: number) {
  if (!denominator) return null;
  return `${((numerator / denominator) * 100).toFixed(1).replace('.', ',')}%`;
}

function integer(value: number | undefined) {
  return new Intl.NumberFormat('pt-BR').format(value ?? 0);
}

export function TrackerKpiRow({ summary }: { summary?: Summary }) {
  const s = summary;
  const [displayCurrency] = useDisplayCurrency();
  const buyersFront = s?.paid_buyers ?? 0;
  const upsells = s?.upsell_orders ?? 0;
  const unmapped = s?.unmapped_paid_orders ?? 0;
  // Every non-BRL sale is converted at ingestion (persisted) and orders
  // that predate the conversion feature fall through a read-time join
  // against exchange_rate_cache in the summary query. The two totals
  // reflect the same underlying revenue, formatted in the operator's
  // preferred currency (persisted via useDisplayCurrency).
  const revenueMinor =
    displayCurrency === 'USD' ? s?.paid_revenue_usd_minor : s?.paid_revenue_brl_minor;
  const revenue = formatMoney(
    revenueMinor && Number(revenueMinor) > 0 ? revenueMinor : s?.paid_revenue_minor,
    displayCurrency,
  );
  const connectRate = s?.ad_clicks ? percent(s.connected_clicks, s.ad_clicks) : null;
  const lossRate = s?.webhooks_received
    ? percent(s.webhooks_quarantined, s.webhooks_received)
    : null;
  const lossTone: 'lush' | 'ember' | 'scar' | 'muted' = !s?.webhooks_received
    ? 'muted'
    : s.webhooks_quarantined === 0
      ? 'lush'
      : s.webhooks_quarantined / s.webhooks_received > 0.1
        ? 'scar'
        : 'ember';
  const connectTone: 'lush' | 'signal' | 'muted' = !s?.ad_clicks
    ? 'muted'
    : s.connected_clicks / s.ad_clicks >= 0.5
      ? 'lush'
      : 'signal';
  // Front-only, per the operator's convention: "taxa de conversão" tracks
  // checkout → front sale. Upsell conversion (front buyer → upsell buyer)
  // is a separate reading below, once per upsell tier.
  const conversionRate = s?.checkouts ? percent(buyersFront, s.checkouts) : null;
  const conversionTone: 'lush' | 'signal' | 'muted' = !s?.checkouts
    ? 'muted'
    : buyersFront / s.checkouts >= 0.1
      ? 'lush'
      : 'signal';
  const upsell2 = s?.upsell_2_orders ?? 0;
  const upsell3 = s?.upsell_3_orders ?? 0;
  const upsell1Rate = buyersFront ? percent(upsells, buyersFront) : null;
  const upsell2Rate = upsells ? percent(upsell2, upsells) : null;
  const upsell3Rate = upsell2 ? percent(upsell3, upsell2) : null;
  const upsellTone = (count: number, previousStep: number): 'lush' | 'signal' | 'muted' =>
    !previousStep ? 'muted' : count / previousStep >= 0.1 ? 'lush' : 'signal';

  const hasFinance = s?.net_revenue_brl_minor !== undefined;
  const refundedOrders = s?.refunded_orders ?? 0;
  const chargebackOrders = s?.chargeback_orders ?? 0;
  const pick = (brlMinor: string | undefined, usdMinor: string | undefined) =>
    formatMoney(displayCurrency === 'USD' ? usdMinor : brlMinor, displayCurrency);
  const feesTotalMinor =
    displayCurrency === 'USD'
      ? Number(s?.fee_vendepay_usd_minor ?? 0) + Number(s?.fee_extra_usd_minor ?? 0)
      : Number(s?.fee_vendepay_brl_minor ?? 0) + Number(s?.fee_extra_brl_minor ?? 0);

  return (
    <div className="tmx-kpi">
      <div className="tmx-kpi-tier1">
        <HeroReading
          eyebrow="Compradores front"
          value={integer(buyersFront)}
          satellite={
            <>
              <span className="tmx-kpi-sat-tag">upsell</span>
              <span className="mono-num tmx-kpi-sat-value">{integer(upsells)}</span>
              {unmapped > 0 && (
                <>
                  <span className="tmx-kpi-sat-sep" aria-hidden />
                  <span
                    className="pulse-dot"
                    data-tone="ember"
                    aria-label={`${unmapped} pedidos ainda sem classificação front/upsell`}
                  />
                  <span className="tmx-kpi-sat-tag tmx-kpi-sat-tag-warn">
                    {integer(unmapped)} não mapeados
                  </span>
                </>
              )}
            </>
          }
        />
        <HeroReading
          eyebrow="Faturamento"
          value={revenue}
          valueVariant="currency"
          satellite={
            <>
              <span className="tmx-kpi-sat-tag">visitas hoje</span>
              <span className="mono-num tmx-kpi-sat-value">{integer(s?.visitors)}</span>
            </>
          }
        />
      </div>

      <div className="tmx-kpi-tier2 tmx-kpi-tier2-five">
        <StripReading
          label="Connect rate"
          value={connectRate ?? '—'}
          detail={
            s?.ad_clicks ? `${integer(s.connected_clicks)}/${integer(s.ad_clicks)} cliques` : null
          }
          tone={connectTone}
        />
        <StripReading
          label="Checkouts"
          value={integer(s?.checkouts)}
          detail={s?.checkout_events ? `${integer(s.checkout_events)} disparos` : null}
          tone="signal"
        />
        <StripReading
          label="Taxa de conversão"
          value={conversionRate ?? '—'}
          detail={s?.checkouts ? `${integer(buyersFront)}/${integer(s.checkouts)} checkouts` : null}
          tone={conversionTone}
        />
        <StripReading
          label="Pedidos totais"
          value={integer(buyersFront + upsells + upsell2 + upsell3 + unmapped)}
          detail={
            unmapped > 0
              ? `${integer(buyersFront)} front · ${integer(upsells + upsell2 + upsell3)} upsells · ${integer(unmapped)} não mapeados`
              : `${integer(buyersFront)} front · ${integer(upsells + upsell2 + upsell3)} upsells`
          }
          tone={buyersFront + upsells + upsell2 + upsell3 > 0 ? 'lush' : 'muted'}
        />
        <StripReading
          label="Perda de dados"
          value={lossRate ?? '—'}
          detail={
            s?.webhooks_received
              ? `${integer(s.webhooks_quarantined)}/${integer(s.webhooks_received)} webhooks`
              : null
          }
          tone={lossTone}
        />
      </div>

      <p className="hud-label mt-5 mb-2">Conversão de upsell por etapa anterior</p>
      <div className="tmx-kpi-tier2">
        <StripReading
          label="Conversão Upsell 1"
          value={upsell1Rate ?? '—'}
          detail={
            buyersFront ? `${integer(upsells)}/${integer(buyersFront)} compradores front` : null
          }
          tone={upsellTone(upsells, buyersFront)}
        />
        <StripReading
          label="Conversão Upsell 2"
          value={upsell2Rate ?? '—'}
          detail={upsells ? `${integer(upsell2)}/${integer(upsells)} compradores Upsell 1` : null}
          tone={upsellTone(upsell2, upsells)}
        />
        <StripReading
          label="Conversão Upsell 3"
          value={upsell3Rate ?? '—'}
          detail={upsell2 ? `${integer(upsell3)}/${integer(upsell2)} compradores Upsell 2` : null}
          tone={upsellTone(upsell3, upsell2)}
        />
      </div>

      {hasFinance && (
        <>
          <p className="hud-label mt-5 mb-2">Financeiro (taxas Vendepay)</p>
          <div className="tmx-kpi-tier2">
            <StripReading
              label="Reembolsos"
              value={pick(s?.refunded_revenue_brl_minor, s?.refunded_revenue_usd_minor)}
              detail={refundedOrders > 0 ? `${integer(refundedOrders)} pedidos` : null}
              tone={refundedOrders > 0 ? 'ember' : 'muted'}
            />
            <StripReading
              label="Chargeback"
              value={pick(s?.chargeback_revenue_brl_minor, s?.chargeback_revenue_usd_minor)}
              detail={chargebackOrders > 0 ? `${integer(chargebackOrders)} pedidos` : null}
              tone={chargebackOrders > 0 ? 'scar' : 'muted'}
            />
            <StripReading
              label="Taxas Vendepay"
              value={formatMoney(String(feesTotalMinor), displayCurrency)}
              detail="taxa + extra por venda"
              tone="signal"
            />
            <StripReading
              label="Taxa de reembolso/chargeback"
              value={pick(s?.refund_chargeback_fee_brl_minor, s?.refund_chargeback_fee_usd_minor)}
              detail={`${integer(s?.refund_chargeback_fee_count)} ocorrências · US$ 27 cada`}
              tone={(s?.refund_chargeback_fee_count ?? 0) > 0 ? 'scar' : 'muted'}
            />
            <StripReading
              label="Em reserva (retido)"
              value={pick(s?.reserve_brl_minor, s?.reserve_usd_minor)}
              detail={
                s?.fee_settings
                  ? `soma ao líquido em ${integer(s.fee_settings.reserve_days)} dias`
                  : null
              }
              tone="muted"
            />
          </div>
          <div className="tmx-kpi-tier1 mt-2">
            <HeroReading
              eyebrow="Disponível real agora"
              value={pick(s?.net_available_brl_minor, s?.net_available_usd_minor)}
              valueVariant="currency"
              satellite={
                <span className="tmx-kpi-sat-tag">
                  reserva e taxas de reembolso/chargeback descontadas
                </span>
              }
            />
            <HeroReading
              eyebrow="Líquido total (reserva já liberada)"
              value={pick(s?.net_revenue_brl_minor, s?.net_revenue_usd_minor)}
              valueVariant="currency"
              satellite={
                <>
                  <span className="tmx-kpi-sat-tag">disponível agora</span>
                  <span className="mono-num tmx-kpi-sat-value">
                    {pick(s?.net_available_brl_minor, s?.net_available_usd_minor)}
                  </span>
                  <span className="tmx-kpi-sat-sep" aria-hidden />
                  <span className="tmx-kpi-sat-tag">+ reserva</span>
                  <span className="mono-num tmx-kpi-sat-value">
                    {pick(s?.reserve_brl_minor, s?.reserve_usd_minor)}
                  </span>
                </>
              }
            />
          </div>
        </>
      )}
    </div>
  );
}

function HeroReading({
  eyebrow,
  value,
  valueVariant = 'count',
  satellite,
}: {
  eyebrow: string;
  value: string;
  valueVariant?: 'count' | 'currency';
  satellite: React.ReactNode;
}) {
  return (
    <div className="tmx-kpi-hero">
      <p className="tmx-kpi-hero-eyebrow">{eyebrow}</p>
      <p
        className={cn(
          'mono-num tmx-kpi-hero-value',
          valueVariant === 'currency' && 'tmx-kpi-hero-value-currency',
        )}
      >
        {value}
      </p>
      <div className="tmx-kpi-hero-sat">{satellite}</div>
    </div>
  );
}

function StripReading({
  label,
  value,
  detail,
  tone,
}: {
  label: string;
  value: string;
  detail: string | null;
  tone: 'lush' | 'ember' | 'scar' | 'signal' | 'muted';
}) {
  return (
    <div className="tmx-kpi-strip-cell">
      <div className="tmx-kpi-strip-head">
        <span
          className={cn('pulse-dot', tone === 'muted' && 'tmx-kpi-dot-muted')}
          data-tone={tone === 'muted' ? undefined : tone}
          aria-hidden
        />
        <span className="tmx-kpi-strip-label">{label}</span>
      </div>
      <p className="mono-num tmx-kpi-strip-value">{value}</p>
      {detail && <p className="tmx-kpi-strip-detail">{detail}</p>}
    </div>
  );
}
