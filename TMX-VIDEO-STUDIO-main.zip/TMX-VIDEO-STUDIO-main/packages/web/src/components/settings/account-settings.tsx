'use client';

import { useState } from 'react';
import { KeyRound, Loader2, LogOut, ShieldCheck, UserRound } from 'lucide-react';
import { toast } from 'sonner';
import { apiClient } from '@/lib/api-client';
import { useAuth } from '@/lib/auth-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export function AccountSettings() {
  const { user, logout } = useAuth();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (newPassword.length < 8) return toast.error('A nova senha deve ter pelo menos 8 caracteres.');
    if (newPassword !== confirmation) return toast.error('A confirmação não corresponde à nova senha.');
    setSaving(true);
    try {
      await apiClient.changePassword(currentPassword, newPassword);
      setCurrentPassword(''); setNewPassword(''); setConfirmation('');
      toast.success('Senha atualizada com segurança.');
    } catch (error) {
      toast.error((error as Error).message);
    } finally { setSaving(false); }
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <header>
        <p className="hud-label">Sua conta</p>
        <h1 className="mt-2 text-3xl font-bold text-white">Configurações</h1>
        <p className="mt-2 text-sm text-white/50">Gerencie seu perfil, segurança e sessão no Nutralisser HUB.</p>
      </header>
      <Tabs defaultValue="account">
        <TabsList className="mb-5 h-auto"><TabsTrigger value="account">Conta</TabsTrigger><TabsTrigger value="security">Segurança</TabsTrigger></TabsList>
        <TabsContent value="account" className="space-y-4">
          <section className="glass-card p-5">
            <div className="mb-5 flex items-center gap-3"><UserRound className="h-5 w-5 text-cyan-300" /><div><p className="font-semibold text-white">Dados da conta</p><p className="text-xs text-white/45">Identidade e nível de acesso atual</p></div></div>
            <dl className="grid gap-4 sm:grid-cols-2">
              <div><dt className="hud-label">Nome</dt><dd className="mt-1 text-sm text-white/85">{user?.name}</dd></div>
              <div><dt className="hud-label">E-mail</dt><dd className="mt-1 text-sm text-white/85">{user?.email}</dd></div>
              <div><dt className="hud-label">Perfil</dt><dd className="mt-1 inline-flex items-center gap-2 text-sm text-white/85"><ShieldCheck className="h-4 w-4 text-emerald-300" />{user?.role === 'admin' ? 'Administrador' : 'Usuário'}</dd></div>
              <div><dt className="hud-label">Permissões</dt><dd className="mt-1 text-sm text-white/85">{user?.role === 'admin' || !user?.allowedTools?.length ? 'Acesso completo' : user.allowedTools.join(', ')}</dd></div>
            </dl>
          </section>
          <section className="glass-card flex flex-wrap items-center justify-between gap-4 p-5"><div><p className="font-semibold text-white">Sessão atual</p><p className="mt-1 text-xs text-white/45">Encerre o acesso neste dispositivo.</p></div><Button variant="outline" onClick={logout}><LogOut className="h-4 w-4" />Sair da conta</Button></section>
        </TabsContent>
        <TabsContent value="security">
          <form onSubmit={submit} className="glass-card space-y-5 p-5">
            <div className="flex items-center gap-3"><KeyRound className="h-5 w-5 text-cyan-300" /><div><p className="font-semibold text-white">Alterar senha</p><p className="text-xs text-white/45">Use no mínimo 8 caracteres e não repita a senha atual.</p></div></div>
            <div className="grid gap-4"><label className="space-y-2"><span className="hud-label">Senha atual</span><Input type="password" autoComplete="current-password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required /></label><label className="space-y-2"><span className="hud-label">Nova senha</span><Input type="password" autoComplete="new-password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required minLength={8} /></label><label className="space-y-2"><span className="hud-label">Confirmar nova senha</span><Input type="password" autoComplete="new-password" value={confirmation} onChange={(e) => setConfirmation(e.target.value)} required minLength={8} /></label></div>
            <div className="flex justify-end"><Button type="submit" disabled={saving}>{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <KeyRound className="h-4 w-4" />}Atualizar senha</Button></div>
          </form>
        </TabsContent>
      </Tabs>
    </div>
  );
}
