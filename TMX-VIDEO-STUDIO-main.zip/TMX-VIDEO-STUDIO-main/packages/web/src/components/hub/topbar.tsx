'use client';

import Link from 'next/link';
import Image from 'next/image';
import type { ReactNode } from 'react';

interface TopbarProps {
  /** Optional breadcrumb segments after the brand. e.g. ['CLONER'] or ['CLONER', 'JOB ABC123']. */
  breadcrumb?: string[];
  /** Right-side slot (status pill, build button, action buttons). */
  right?: ReactNode;
}

export function Topbar({ breadcrumb, right }: TopbarProps) {
  return (
    <header
      className="tmx-topbar flex h-16 shrink-0 items-center gap-2 border-b border-cyan-100/[0.09] bg-[#10281f]/92 px-3 shadow-[0_10px_35px_rgba(0,0,0,.18)] backdrop-blur-2xl sm:gap-4 sm:px-6"
      style={{ position: 'sticky', top: 0, zIndex: 30 }}
    >
      <Link href="/" className="group flex min-w-0 shrink-0 items-center gap-2 sm:gap-3">
        <span className="overflow-hidden rounded-md bg-[#f5f0e4] px-2 py-1 shadow-[0_0_20px_rgba(215,199,156,.12)]">
          <Image src="/brand/nutralisse-logo.jpg" width={142} height={40} alt="Nutralisse" className="h-7 w-auto object-contain" priority />
        </span>
        <span className="flex flex-col leading-tight">
          <span className="text-[16px] font-semibold tracking-[0.12em] text-[#ece3cb] sm:text-[18px]">HUB</span>
          <span className="hidden text-[9px] font-semibold uppercase tracking-[0.16em] text-white/55 sm:block">
            CREATIVE INTELLIGENCE
          </span>
        </span>
      </Link>

      {breadcrumb && breadcrumb.length > 0 && (
        <nav
          aria-label="Breadcrumb"
          className="hidden items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/40 md:flex"
        >
          <span aria-hidden className="text-white/40">
            /
          </span>
          {breadcrumb.map((crumb, i) => (
            <span key={crumb} className="flex items-center gap-2">
              <span className={i === breadcrumb.length - 1 ? 'text-white/70' : ''}>{crumb}</span>
              {i < breadcrumb.length - 1 && (
                <span aria-hidden className="text-white/25">
                  ›
                </span>
              )}
            </span>
          ))}
        </nav>
      )}

      <div className="ml-auto flex min-w-0 items-center gap-1.5 sm:gap-2">{right}</div>
    </header>
  );
}
