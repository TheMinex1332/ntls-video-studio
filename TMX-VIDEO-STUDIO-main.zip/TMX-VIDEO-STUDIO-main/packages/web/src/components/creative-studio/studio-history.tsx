'use client';

import { Button } from '@/components/ui/button';
import { apiClient, type MediaJobView } from '@/lib/api-client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Archive, CheckCircle2, Download, FileVideo2, Loader2, Search, Trash2, XCircle, type LucideIcon } from 'lucide-react';
import { useMemo, useState } from 'react';
import { toast } from 'sonner';

type StatusFilter = 'all' | MediaJobView['status'];

const statusLabel: Record<MediaJobView['status'], string> = {
  queued: 'Na fila', processing: 'Processando', verifying: 'Verificando', ready: 'Concluído', failed: 'Falhou',
};

function bytes(value = 0) {
  if (!value) return '0 MB';
  return `${(value / 1024 / 1024).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} MB`;
}

function dateTime(value: string) {
  return new Intl.DateTimeFormat('pt-BR', {
    timeZone: 'America/Sao_Paulo', dateStyle: 'short', timeStyle: 'short',
  }).format(new Date(value));
}

export function StudioHistory() {
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState<StatusFilter>('all');
  const [ownerId, setOwnerId] = useState('all');
  const [selected, setSelected] = useState<string[]>([]);
  const jobsQuery = useQuery({
    queryKey: ['media-jobs'],
    queryFn: () => apiClient.listMediaJobs(),
    refetchInterval: (query) =>
      (query.state.data ?? []).some((job) => ['queued', 'processing', 'verifying'].includes(job.status)) ? 2500 : false,
  });
  const jobs = jobsQuery.data ?? [];
  const owners = useMemo(() => {
    const unique = new Map<string, NonNullable<MediaJobView['owner']>>();
    for (const job of jobs) if (job.owner) unique.set(job.owner.id, job.owner);
    return [...unique.values()].sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
  }, [jobs]);
  const isAdminHistory = owners.length > 0;
  const filtered = useMemo(() => jobs.filter((job) => {
    const matchesStatus = status === 'all' || job.status === status;
    const matchesOwner = ownerId === 'all' || job.owner?.id === ownerId;
    const term = search.trim().toLowerCase();
    return matchesStatus && matchesOwner && (!term || job.input.filename.toLowerCase().includes(term) || job.id.toLowerCase().includes(term) || job.owner?.name.toLowerCase().includes(term) || job.owner?.email.toLowerCase().includes(term));
  }), [jobs, ownerId, search, status]);
  const readyIds = filtered.filter((job) => job.status === 'ready').map((job) => job.id);
  const stats = {
    total: jobs.length,
    ready: jobs.filter((job) => job.status === 'ready').length,
    active: jobs.filter((job) => ['queued', 'processing', 'verifying'].includes(job.status)).length,
    failed: jobs.filter((job) => job.status === 'failed').length,
    outputBytes: jobs.reduce((sum, job) => sum + (job.output?.bytes ?? 0), 0),
  };
  const deleteJob = useMutation({
    mutationFn: (id: string) => apiClient.deleteMediaJob(id),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: ['media-jobs'] }); toast.success('Processamento removido.'); },
    onError: (error) => toast.error((error as Error).message),
  });
  const downloadSelected = async () => {
    const ids = selected.filter((id) => readyIds.includes(id));
    if (!ids.length) return toast.error('Selecione pelo menos um vídeo concluído.');
    try { await apiClient.bulkDownloadMediaJobs(ids); toast.success(`${ids.length} vídeo(s) baixado(s) em ZIP.`); }
    catch (error) { toast.error((error as Error).message); }
  };

  return <div className="space-y-6">
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
      {([
        ['Processamentos', stats.total, FileVideo2], ['Concluídos', stats.ready, CheckCircle2],
        ['Em andamento', stats.active, Loader2], ['Falhas', stats.failed, XCircle], ['Gerado', bytes(stats.outputBytes), Archive],
      ] as Array<[string, string | number, LucideIcon]>).map(([label, value, Icon]) => <div key={String(label)} className="glass-card p-4">
        <div className="flex items-center justify-between"><p className="hud-label">{String(label)}</p><Icon className="h-4 w-4 text-cyan-300" /></div>
        <p className="mt-3 font-mono text-2xl font-semibold text-white">{String(value)}</p>
      </div>)}
    </div>

    <section className="glass-card overflow-hidden">
      <div className="flex flex-col gap-3 border-b border-white/[0.07] p-4 md:flex-row md:items-center md:justify-between">
        <div><p className="hud-label">Histórico dedicado</p><p className="mt-1 text-xs text-white/45">Biblioteca permanente e exclusiva do Nutralisser HUB.</p></div>
        <div className="flex flex-wrap gap-2">
          <label className="flex h-10 min-w-56 items-center gap-2 rounded-lg border border-white/10 bg-black/20 px-3">
            <Search className="h-4 w-4 text-white/35" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar arquivo ou ID" className="w-full bg-transparent text-sm text-white outline-none placeholder:text-white/30" />
          </label>
          <select value={status} onChange={(e) => setStatus(e.target.value as StatusFilter)} className="h-10 rounded-lg border border-white/10 bg-[#071923] px-3 text-sm text-white outline-none">
            <option value="all">Todos os status</option>{Object.entries(statusLabel).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select>
          {isAdminHistory && <select value={ownerId} onChange={(e) => setOwnerId(e.target.value)} className="h-10 rounded-lg border border-white/10 bg-[#071923] px-3 text-sm text-white outline-none">
            <option value="all">Todas as contas</option>{owners.map((owner) => <option key={owner.id} value={owner.id}>{owner.name} · {owner.email}</option>)}
          </select>}
          <Button variant="outline" onClick={() => void downloadSelected()} disabled={!selected.length}><Download className="h-4 w-4" />Baixar ZIP</Button>
        </div>
      </div>

      {jobsQuery.isLoading ? <div className="grid min-h-48 place-items-center"><Loader2 className="h-6 w-6 animate-spin text-cyan-300" /></div> : filtered.length === 0 ?
        <div className="grid min-h-48 place-items-center text-sm text-white/40">Nenhum processamento encontrado.</div> :
        <div className="overflow-x-auto"><table className="w-full min-w-[920px] text-left text-sm">
          <thead className="bg-white/[0.025] text-[10px] uppercase tracking-[0.16em] text-white/40"><tr><th className="p-4"><input type="checkbox" aria-label="Selecionar concluídos" checked={readyIds.length > 0 && readyIds.every((id) => selected.includes(id))} onChange={(e) => setSelected(e.target.checked ? readyIds : [])} /></th><th>Arquivo</th>{isAdminHistory && <th>Conta</th>}<th>Status</th><th>Data</th><th>Tamanho</th><th className="pr-4 text-right">Ações</th></tr></thead>
          <tbody>{filtered.map((job) => <tr key={job.id} className="border-t border-white/[0.055] text-white/70">
            <td className="p-4"><input type="checkbox" disabled={job.status !== 'ready'} checked={selected.includes(job.id)} onChange={(e) => setSelected((current) => e.target.checked ? [...new Set([...current, job.id])] : current.filter((id) => id !== job.id))} /></td>
            <td className="max-w-[320px] py-4"><p className="truncate font-medium text-white">{job.input.filename}</p><p className="mt-1 font-mono text-[10px] text-white/30">{job.id}</p></td>
            {isAdminHistory && <td className="max-w-56"><p className="truncate text-xs font-medium text-white/80">{job.owner?.name ?? 'Conta removida'}</p><p className="truncate text-[10px] text-white/35">{job.owner?.email ?? job.owner?.id ?? 'Sem identificação'}</p></td>}
            <td><span className="rounded-full border border-cyan-300/20 bg-cyan-300/[0.06] px-2.5 py-1 text-xs text-cyan-100">{statusLabel[job.status]}</span>{job.error && <p className="mt-1 max-w-64 truncate text-[10px] text-rose-300">{job.error}</p>}</td>
            <td className="font-mono text-xs">{dateTime(job.created_at)}</td><td className="font-mono text-xs">{bytes(job.output?.bytes ?? job.input.bytes)}</td>
            <td className="pr-4"><div className="flex justify-end gap-1">{job.status === 'ready' && <Button size="sm" variant="outline" onClick={() => void apiClient.downloadMediaJob(job.id)}><Download className="h-3.5 w-3.5" />Baixar</Button>}<Button size="sm" variant="ghost" onClick={() => { if (confirm(`Remover ${job.input.filename}?`)) deleteJob.mutate(job.id); }}><Trash2 className="h-3.5 w-3.5" /></Button></div></td>
          </tr>)}</tbody>
        </table></div>}
    </section>
  </div>;
}
