'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useState } from 'react';
import { Loader2, LogIn } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/lib/auth-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

// Auth pages don't benefit from SSG and useSearchParams (?next=) requires
// a Suspense boundary in Next 15 — both fixed by opting out of prerender.
export const dynamic = 'force-dynamic';

function LoginForm() {
  const router = useRouter();
  const search = useSearchParams();
  const next = search.get('next') ?? '/';
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await login(email, password);
      toast.success('Login efetuado.');
      router.replace(next);
    } catch (err) {
      toast.error((err as Error).message);
      setSubmitting(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-[#091912] p-6">
      <div className="w-full max-w-sm space-y-6">
        <div className="text-center">
          <Link href="/" className="inline-flex flex-col items-center gap-2">
            <span className="overflow-hidden rounded-xl bg-[#f5f0e4] px-5 py-2 shadow-[0_20px_60px_rgba(0,0,0,.35)]">
              <Image src="/brand/nutralisse-logo.jpg" width={300} height={85} alt="Nutralisse" className="h-14 w-auto object-contain" priority />
            </span>
            <span className="text-[11px] font-semibold uppercase tracking-[0.28em] text-[#d7c79c]">HUB</span>
          </Link>
          <p className="mt-4 text-[12px] uppercase tracking-[0.18em] text-white/45">
            Creative intelligence platform
          </p>
        </div>

        <form onSubmit={onSubmit} className="glass-card space-y-4 p-6">
          <div className="space-y-2">
            <Label htmlFor="email" className="hud-label">Email</Label>
            <Input
              id="email"
              type="email"
              required
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={submitting}
              placeholder="voce@exemplo.com"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password" className="hud-label">Senha</Label>
            <Input
              id="password"
              type="password"
              required
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={submitting}
              placeholder="••••••••"
            />
          </div>
          <Button type="submit" disabled={submitting} className="w-full" size="lg">
            {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4" />}
            {submitting ? 'Entrando…' : 'Entrar'}
          </Button>
          <p className="text-center text-[12px] text-white/40">
            Não tem conta?{' '}
            <Link href="/register" className="text-cyan-300 hover:underline">
              Solicitar acesso
            </Link>
          </p>
        </form>
      </div>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="grid min-h-screen place-items-center bg-[#04101A] text-white/40">
          <Loader2 className="h-6 w-6 animate-spin" />
        </div>
      }
    >
      <LoginForm />
    </Suspense>
  );
}
