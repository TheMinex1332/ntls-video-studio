import { HubShell } from '@/components/hub/hub-shell';
import { AccountSettings } from '@/components/settings/account-settings';

export const dynamic = 'force-dynamic';

export default function SettingsPage() {
  return (
    <HubShell breadcrumb={['CONFIGURAÇÕES']}>
      <AccountSettings />
    </HubShell>
  );
}
