import { StudioHistory } from '@/components/creative-studio/studio-history';
import { HubShell } from '@/components/hub/hub-shell';

export const dynamic = 'force-dynamic';

export default function HistoryPage() {
  return <HubShell breadcrumb={['HISTÓRICO']}>
    <div className="space-y-6">
      <header><p className="hud-label">Biblioteca operacional</p><h1 className="mt-2 text-3xl font-bold text-white">Histórico de processamento</h1><p className="mt-2 text-sm text-white/50">Acompanhe resultados, falhas, armazenamento e downloads da sua equipe.</p></header>
      <StudioHistory />
    </div>
  </HubShell>;
}
