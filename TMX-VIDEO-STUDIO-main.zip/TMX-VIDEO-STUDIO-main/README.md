# Nutralisser HUB

Plataforma independente da Nutralisser para preparação, proteção e gestão de criativos em vídeo.

## Recursos

- Upload e processamento de até 30 vídeos por lote.
- Compressão, normalização, remoção de metadados e adaptação de proporção.
- Extensão por loop ou congelamento do frame final.
- Phase Cancel com White Audio configurável.
- Phase Cancel somente com inversão, sem faixa adicional.
- Verificação opcional com AssemblyAI.
- Histórico permanente e dedicado de processamentos.
- Download individual pelo próprio TMX.
- Seleção múltipla e download em arquivo ZIP.
- Gestão de usuários e permissões.

## Arquitetura

- `packages/web`: Next.js 15 e interface do Studio.
- `packages/api`: Fastify, filas BullMQ e workers FFmpeg.
- `packages/shared`: schemas e contratos compartilhados.
- Redis: filas e estado transitório.
- Redis persistente: autenticação, usuários, histórico e filas.
- Storage compatível com S3/R2: vídeos de entrada e saída.

## Desenvolvimento

Requisitos: Node.js 22, pnpm 9, Redis e FFmpeg.

```bash
pnpm install
pnpm typecheck
pnpm build
pnpm dev
```

Copie `.env.example` para `.env` e configure banco, Redis, storage e autenticação.

## Deploy

Os Dockerfiles de web e API estão em `packages/web/Dockerfile` e `packages/api/Dockerfile`.
Para Railway, crie serviços separados para web, API e Redis. O storage de vídeos deve usar um bucket S3/R2 independente.

### Variáveis da API

- `REDIS_URL`
- `JWT_SECRET`
- `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_NAME`
- `PUBLIC_BASE_URL`
- `S3_ENDPOINT`, `S3_REGION`, `S3_BUCKET`, `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `S3_FORCE_PATH_STYLE`
- `MEDIA_WORKER_CONCURRENCY` (padrão `2`) e `FFMPEG_THREADS_PER_JOB` (padrão `2`)
- Para separar API e processamento: use `MEDIA_WORKER_ENABLED=false` na API e inicie outro serviço com `railway-worker.toml`.
- `ASSEMBLYAI_API_KEY` (opcional)
- `ALLOW_REGISTRATION=false`

### Variáveis da Web

- `NEXT_PUBLIC_API_URL`
- `API_PROXY_TARGET`

Use volume persistente no Redis para que usuários e histórico sobrevivam a reinícios.

## Segurança

O repositório não deve conter tokens, senhas ou chaves reais. Mantenha credenciais apenas no provedor de deploy.
